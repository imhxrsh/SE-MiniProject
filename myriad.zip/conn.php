<?php
$conn = mysqli_connect('localhost','root','','mmt_scraped') or die('Connection could not be established');
?>